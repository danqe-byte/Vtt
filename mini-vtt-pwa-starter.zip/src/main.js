import * as PIXI from 'pixi.js';

// Register service worker for PWA
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js');
  });
}

const app = new PIXI.Application();
await app.init({ background: '#0d1117', resizeTo: window });
document.getElementById('app').appendChild(app.canvas);

// Load map texture
const mapTexture = await PIXI.Assets.load('/assets/map.jpg');
const map = new PIXI.Sprite(mapTexture);
map.anchor.set(0);
map.x = 0;
map.y = 0;
app.stage.addChild(map);

// Scale map to fit screen (keep aspect)
const fitMap = () => {
  const scaleX = app.renderer.width / map.texture.width;
  const scaleY = app.renderer.height / map.texture.height;
  const scale = Math.max(scaleX, scaleY);
  map.scale.set(scale);
};
fitMap();
window.addEventListener('resize', fitMap);

// Create a draggable token (simple circle)
const tokenGfx = new PIXI.Graphics()
  .circle(0, 0, 28)
  .fill(0xffffff)
  .stroke({ width: 4, color: 0x00ff99 });
const token = new PIXI.Container();
token.addChild(tokenGfx);
token.x = app.renderer.width * 0.5;
token.y = app.renderer.height * 0.5;
token.eventMode = 'static';
token.cursor = 'grab';
app.stage.addChild(token);

// Drag logic
let dragging = false;
token.on('pointerdown', (e) => {
  dragging = true;
  token.cursor = 'grabbing';
  token.alpha = 0.85;
});
app.stage.on('pointerup', () => {
  dragging = false;
  token.cursor = 'grab';
  token.alpha = 1;
});
app.stage.on('pointerupoutside', () => {
  dragging = false;
  token.cursor = 'grab';
  token.alpha = 1;
});
app.stage.on('pointermove', (e) => {
  if (!dragging) return;
  const pos = e.global;
  token.position.copyFrom(pos);
});

// Pinch-zoom and pan over the map (basic gestures)
let lastDist = 0;
let isPanning = false;
let lastPan = null;

const getDist = (t0, t1) => {
  const dx = t0.clientX - t1.clientX;
  const dy = t0.clientY - t1.clientY;
  return Math.hypot(dx, dy);
};

window.addEventListener('touchstart', (e) => {
  if (e.touches.length === 2) {
    lastDist = getDist(e.touches[0], e.touches[1]);
  } else if (e.touches.length === 1) {
    isPanning = true;
    lastPan = { x: e.touches[0].clientX, y: e.touches[0].clientY };
  }
}, { passive: true });

window.addEventListener('touchmove', (e) => {
  if (e.touches.length === 2) {
    const dist = getDist(e.touches[0], e.touches[1]);
    const delta = dist / lastDist;
    lastDist = dist;
    const newScale = Math.min(3, Math.max(0.5, map.scale.x * delta));
    map.scale.set(newScale);
  } else if (e.touches.length === 1 && isPanning && lastPan) {
    const dx = e.touches[0].clientX - lastPan.x;
    const dy = e.touches[0].clientY - lastPan.y;
    map.x += dx;
    map.y += dy;
    lastPan = { x: e.touches[0].clientX, y: e.touches[0].clientY };
  }
}, { passive: true });

window.addEventListener('touchend', () => {
  isPanning = false;
  lastPan = null;
}, { passive: true });

// Simple UI overlay
const banner = document.createElement('div');
banner.style.position = 'fixed';
banner.style.left = '12px';
banner.style.top = '12px';
banner.style.padding = '8px 12px';
banner.style.borderRadius = '12px';
banner.style.background = 'rgba(13,17,23,0.7)';
banner.style.border = '1px solid #263041';
banner.style.color = '#e6edf3';
banner.style.fontFamily = 'system-ui, -apple-system, Segoe UI, Roboto, sans-serif';
banner.style.fontSize = '14px';
banner.innerText = 'Mini VTT • перетащи токен • pinch‑zoom';
document.body.appendChild(banner);
